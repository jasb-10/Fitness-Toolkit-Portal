import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-foreground">
        <span className="font-serif text-lg italic leading-none text-background">
          P
        </span>
      </div>
      <span className="text-sm font-semibold tracking-[0.18em] text-foreground">
        PORTAL
      </span>
    </div>
  );
}
