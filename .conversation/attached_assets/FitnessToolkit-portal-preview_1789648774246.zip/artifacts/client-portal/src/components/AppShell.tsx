import { type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useClerk, useUser } from "@clerk/react";
import {
  Home,
  GraduationCap,
  Briefcase,
  Settings,
  ShieldCheck,
  Users as UsersIcon,
  BookOpen,
  UserCog,
  LogOut,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Rocket,
  LifeBuoy,
  Wrench,
} from "lucide-react";
import { useGetMe } from "@workspace/api-client-react";
import { Logo } from "./Logo";
import { SupportWidget } from "./SupportWidget";
import { cn, initials, isAdmin, isStaff } from "@/lib/utils";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";

interface NavItem {
  label: string;
  href: string;
  icon: typeof Home;
}

const primaryNav: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: Home },
  { label: "Master Class", href: "/courses", icon: GraduationCap },
  { label: "DFY Projects", href: "/projects", icon: Briefcase },
  { label: "Upsell 1", href: "/upsell-1", icon: Sparkles },
  { label: "Upsell 2", href: "/upsell-2", icon: Rocket },
  { label: "Support", href: "/support", icon: LifeBuoy },
];

const adminNavBase: NavItem[] = [
  { label: "Admin Home", href: "/admin", icon: ShieldCheck },
  { label: "Users", href: "/admin/users", icon: UsersIcon },
  { label: "Courses", href: "/admin/courses", icon: BookOpen },
  { label: "Team", href: "/admin/team", icon: UserCog },
];

const adminOnlyNav: NavItem[] = [
  { label: "Support", href: "/admin/support", icon: LifeBuoy },
];

function NavLink({ item }: { item: NavItem }) {
  const [loc] = useLocation();
  const active =
    loc === item.href || (item.href !== "/dashboard" && loc.startsWith(item.href));
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      className={cn(
        "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
        active
          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
          : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground",
      )}
    >
      <Icon className="h-4 w-4 shrink-0" strokeWidth={1.75} />
      <span>{item.label}</span>
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { signOut, openUserProfile } = useClerk();
  const { user: clerkUser } = useUser();
  const { data: me, isLoading } = useGetMe();
  const role = me?.user.role;
  const showAdmin = isStaff(role);
  const adminNav = isAdmin(role)
    ? [...adminNavBase, ...adminOnlyNav]
    : adminNavBase;

  return (
    <div className="flex min-h-screen w-full bg-background">
      <aside className="sticky top-0 flex h-screen w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar">
        <div className="px-5 pt-6 pb-4">
          <Link href="/dashboard">
            <Logo />
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto px-3">
          <div className="space-y-1">
            {primaryNav.map((item) => (
              <NavLink key={item.href} item={item} />
            ))}
          </div>

          <div className="mt-8">
            <div className="px-3 pb-2 text-xs font-medium uppercase tracking-widest text-muted-foreground/70">
              Account
            </div>
            <div className="space-y-1">
              <NavLink
                item={{
                  label: "Settings",
                  href: "/settings/profile",
                  icon: Settings,
                }}
              />
            </div>
          </div>
        </nav>

        {showAdmin && (
          <div className="border-t border-sidebar-border px-3 pt-3">
            <Popover>
              <PopoverTrigger
                data-testid="admin-popover-trigger"
                className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground"
              >
                <Wrench className="h-4 w-4" strokeWidth={1.75} />
                <span className="flex-1 text-left">Admin</span>
                <ChevronUp className="h-4 w-4" />
              </PopoverTrigger>
              <PopoverContent
                side="top"
                align="start"
                className="w-60 p-2"
              >
                <div className="px-2 pb-2 pt-1 text-xs font-medium uppercase tracking-widest text-muted-foreground/70">
                  Admin tools
                </div>
                <div className="space-y-1">
                  {adminNav.map((item) => (
                    <NavLink key={item.href} item={item} />
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        )}

        <div className="border-t border-sidebar-border p-3">
          {isLoading ? (
            <div className="flex items-center gap-3 px-2 py-2">
              <Skeleton className="h-9 w-9 rounded-full" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-3 w-24" />
                <Skeleton className="h-2.5 w-16" />
              </div>
            </div>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger
                data-testid="user-menu-trigger"
                className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left transition-colors hover:bg-sidebar-accent"
              >
                <Avatar className="h-9 w-9">
                  <AvatarImage
                    src={me?.user.avatarUrl ?? clerkUser?.imageUrl ?? undefined}
                  />
                  <AvatarFallback className="bg-foreground text-background text-xs">
                    {initials(me?.user.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium text-foreground">
                    {me?.user.name ?? "Loading"}
                  </div>
                  <div className="truncate text-xs text-muted-foreground capitalize">
                    {role?.replace("_", " ") ?? ""}
                  </div>
                </div>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="text-xs text-muted-foreground">Signed in as</div>
                  <div className="truncate text-sm">{me?.user.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/settings/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/settings/billing">Billing</Link>
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => openUserProfile()}>
                  Account & password
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  data-testid="sign-out-button"
                  onSelect={() => void signOut()}
                  className="text-foreground"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </aside>

      <main className="min-w-0 flex-1">{children}</main>
      <SupportWidget />
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 border-b border-border px-10 pb-8 pt-10 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && (
          <div className="mb-2 text-xs font-medium uppercase tracking-[0.22em] text-muted-foreground">
            {eyebrow}
          </div>
        )}
        <h1 className="font-display text-4xl text-foreground sm:text-5xl">
          {title}
        </h1>
        {description && (
          <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {actions && <div className="flex shrink-0 gap-2">{actions}</div>}
    </div>
  );
}
