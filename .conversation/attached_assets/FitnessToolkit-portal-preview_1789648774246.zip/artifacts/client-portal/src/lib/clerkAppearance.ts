const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export const clerkAppearance = {
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl:
      typeof window !== "undefined"
        ? `${window.location.origin}${basePath}/logo.svg`
        : "/logo.svg",
    socialButtonsPlacement: "top" as const,
    socialButtonsVariant: "blockButton" as const,
  },
  variables: {
    colorPrimary: "#0a0a0a",
    colorForeground: "#0a0a0a",
    colorMutedForeground: "#666666",
    colorDanger: "#1a1a1a",
    colorBackground: "#ffffff",
    colorInput: "#ffffff",
    colorInputForeground: "#0a0a0a",
    colorNeutral: "#0a0a0a",
    colorModalBackdrop: "rgba(10,10,10,0.55)",
    fontFamily: "'Inter', ui-sans-serif, system-ui, sans-serif",
    borderRadius: "0.5rem",
  },
  elements: {
    rootBox: "w-full flex items-center justify-center",
    cardBox:
      "bg-white border border-neutral-200 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.25)] rounded-2xl w-[440px] max-w-full overflow-hidden mx-auto",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none px-2",
    footer:
      "!shadow-none !border-0 !bg-neutral-50 !rounded-none border-t border-neutral-100",
    headerTitle: "font-serif text-2xl text-neutral-900 tracking-tight",
    headerSubtitle: "text-sm text-neutral-500",
    socialButtonsBlockButton:
      "border border-neutral-200 hover:bg-neutral-50 text-neutral-900 rounded-lg",
    socialButtonsBlockButtonText: "text-sm font-medium text-neutral-900",
    formFieldLabel: "text-xs font-medium text-neutral-700 uppercase tracking-wide",
    footerActionLink: "text-neutral-900 font-medium hover:underline",
    footerActionText: "text-sm text-neutral-500",
    dividerText: "text-neutral-400 text-xs uppercase tracking-widest",
    dividerLine: "bg-neutral-200",
    identityPreviewEditButton: "text-neutral-900 hover:underline",
    formFieldSuccessText: "text-neutral-900 text-sm",
    alertText: "text-neutral-900 text-sm",
    logoBox: "flex items-center justify-center mb-2",
    logoImage: "h-9 w-auto",
    formButtonPrimary:
      "bg-neutral-900 hover:bg-black text-white font-medium rounded-lg shadow-none normal-case tracking-normal",
    formFieldInput:
      "border border-neutral-200 bg-white text-neutral-900 rounded-lg focus:border-neutral-900 focus:ring-0",
    footerAction: "py-3",
    alert: "border border-neutral-200 bg-neutral-50 text-neutral-900",
    otpCodeFieldInput:
      "border border-neutral-200 bg-white text-neutral-900 rounded-lg",
    formFieldRow: "gap-1",
    main: "gap-4",
    userPreviewMainIdentifier: "text-neutral-900",
  },
};
