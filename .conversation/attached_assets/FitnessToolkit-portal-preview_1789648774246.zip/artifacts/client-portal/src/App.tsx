import { useEffect, useRef } from "react";
import {
  ClerkProvider,
  SignIn,
  SignUp,
  Show,
  useClerk,
} from "@clerk/react";
import {
  Switch,
  Route,
  useLocation,
  Redirect,
  Router as WouterRouter,
} from "wouter";
import {
  QueryClientProvider,
  useQueryClient,
} from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { queryClient } from "@/lib/queryClient";
import { clerkAppearance } from "@/lib/clerkAppearance";
import { basePath } from "@/lib/utils";
import { track } from "@/lib/track";

import DashboardPage from "@/pages/dashboard";
import CoursesPage from "@/pages/courses";
import CoursePlayerPage from "@/pages/course-player";
import ProjectsPage from "@/pages/projects";
import ProjectDetailPage from "@/pages/project-detail";
import ProfileSettingsPage from "@/pages/settings-profile";
import BillingSettingsPage from "@/pages/settings-billing";
import AdminHomePage from "@/pages/admin-home";
import AdminUsersPage from "@/pages/admin-users";
import AdminUserDetailPage from "@/pages/admin-user-detail";
import AdminCoursesPage from "@/pages/admin-courses";
import AdminCourseEditPage from "@/pages/admin-course-edit";
import AdminTeamPage from "@/pages/admin-team";
import AdminSupportPage from "@/pages/admin-support";
import Upsell1Page from "@/pages/upsell-1";
import Upsell2Page from "@/pages/upsell-2";
import SupportPage from "@/pages/support";
import NotFound from "@/pages/not-found";
import ProductPreviewPage from "@/pages/product-preview";
import WebsitePrototypePage from "@/pages/website-prototype";

const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY as string;
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL as string | undefined;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

function HomeRoute() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/comeback" />
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function Protected({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Show when="signed-in">
        <PageViewTracker />
        {children}
      </Show>
      <Show when="signed-out">
        <Redirect to="/sign-in" />
      </Show>
    </>
  );
}

function PageViewTracker() {
  const [path] = useLocation();
  useEffect(() => {
    track("viewed_page", {
      target: typeof document !== "undefined" ? document.title : path,
      path,
    });
  }, [path]);
  return null;
}

function SignInPage() {
  // To update login providers, app branding, or OAuth settings use the Auth
  // pane in the workspace toolbar. More information can be found in the Replit docs.
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-neutral-50 px-4">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
      />
    </div>
  );
}

function SignUpPage() {
  // To update login providers, app branding, or OAuth settings use the Auth
  // pane in the workspace toolbar. More information can be found in the Replit docs.
  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-center gap-4 bg-neutral-50 px-4 py-10">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
      />
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prev = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsub = addListener(({ user }) => {
      const id = user?.id ?? null;
      if (prev.current !== undefined && prev.current !== id) {
        qc.clear();
      }
      prev.current = id;
    });
    return unsub;
  }, [addListener, qc]);
  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  // The design preview is intentionally usable before account and API setup.
  if (window.location.pathname.startsWith("/preview")) return <WebsitePrototypePage />;
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to continue your work",
          },
        },
        signUp: {
          start: {
            title: "Create your account",
            subtitle: "Begin where you left off",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Switch>
            <Route path="/preview/*?" component={WebsitePrototypePage} />
            <Route path="/" component={HomeRoute} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />

            <Route path="/dashboard">
              <Protected><DashboardPage /></Protected>
            </Route>
            <Route path="/comeback/*?">
              <Protected><ProductPreviewPage /></Protected>
            </Route>
            <Route path="/courses">
              <Protected><CoursesPage /></Protected>
            </Route>
            <Route path="/courses/:courseId">
              {(p) => (
                <Protected><CoursePlayerPage courseId={p.courseId!} /></Protected>
              )}
            </Route>
            <Route path="/projects">
              <Protected><ProjectsPage /></Protected>
            </Route>
            <Route path="/projects/:projectId">
              {(p) => (
                <Protected><ProjectDetailPage projectId={p.projectId!} /></Protected>
              )}
            </Route>
            <Route path="/settings/profile">
              <Protected><ProfileSettingsPage /></Protected>
            </Route>
            <Route path="/settings/billing">
              <Protected><BillingSettingsPage /></Protected>
            </Route>
            <Route path="/settings">
              <Redirect to="/settings/profile" />
            </Route>

            <Route path="/admin">
              <Protected><AdminHomePage /></Protected>
            </Route>
            <Route path="/admin/users">
              <Protected><AdminUsersPage /></Protected>
            </Route>
            <Route path="/admin/users/:userId">
              {(p) => (
                <Protected><AdminUserDetailPage userId={p.userId!} /></Protected>
              )}
            </Route>
            <Route path="/admin/courses">
              <Protected><AdminCoursesPage /></Protected>
            </Route>
            <Route path="/admin/courses/:courseId/edit">
              {(p) => (
                <Protected><AdminCourseEditPage courseId={p.courseId!} /></Protected>
              )}
            </Route>
            <Route path="/admin/team">
              <Protected><AdminTeamPage /></Protected>
            </Route>
            <Route path="/admin/support">
              <Protected><AdminSupportPage /></Protected>
            </Route>

            <Route path="/upsell-1">
              <Protected><Upsell1Page /></Protected>
            </Route>
            <Route path="/upsell-2">
              <Protected><Upsell2Page /></Protected>
            </Route>
            <Route path="/support">
              <Protected><SupportPage /></Protected>
            </Route>

            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}
