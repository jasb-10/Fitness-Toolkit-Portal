import { useMemo, useState } from "react";
import { useListSupportArticles } from "@workspace/api-client-react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, MessageCircle } from "lucide-react";

const UNCATEGORIZED = "General";

export default function SupportPage() {
  const { data, isLoading } = useListSupportArticles();
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    if (!data) return [];
    const term = q.trim().toLowerCase();
    if (!term) return data;
    return data.filter(
      (a) =>
        a.title.toLowerCase().includes(term) ||
        a.body.toLowerCase().includes(term) ||
        (a.category ?? "").toLowerCase().includes(term),
    );
  }, [data, q]);

  const articles = filtered.filter((a) => a.kind === "article");
  const faqs = filtered.filter((a) => a.kind === "faq");

  const articlesBySection = useMemo(() => {
    const byCat: Record<string, typeof articles> = {};
    for (const a of articles) {
      const key = a.category?.trim() || UNCATEGORIZED;
      (byCat[key] ??= []).push(a);
    }
    return Object.entries(byCat).sort(([a], [b]) => a.localeCompare(b));
  }, [articles]);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Help"
        title="Support"
        description="Browse help articles and frequently asked questions. Need a hand? Tap the chat bubble to talk to our assistant."
      />
      <div className="space-y-8 px-10 py-10">
        <Input
          placeholder="Search articles and FAQs…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="max-w-xl"
          data-testid="kb-search"
        />

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center gap-3 py-16 text-center text-sm text-muted-foreground">
              <MessageCircle className="h-6 w-6" />
              <div>
                Nothing matches your search. Open the chat bubble in the corner
                and ask the assistant directly.
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-12">
            {articlesBySection.map(([section, items]) => (
              <Section key={section} title={section}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {items.map((a) => (
                    <ArticleCard key={a.id} article={a} />
                  ))}
                </div>
              </Section>
            ))}

            {faqs.length > 0 && (
              <Section title="Frequently asked">
                <div className="space-y-2">
                  {faqs.map((a) => (
                    <FaqRow key={a.id} faq={a} />
                  ))}
                </div>
              </Section>
            )}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <div className="mb-4 flex items-baseline justify-between">
        <h2 className="font-display text-2xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function ArticleCard({
  article,
}: {
  article: { id: string; title: string; body: string; category?: string | null };
}) {
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
        data-testid={`article-${article.id}`}
      >
        <div className="min-w-0">
          <div className="truncate font-medium">{article.title}</div>
          <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">
            {article.body.slice(0, 140)}
          </div>
        </div>
        <BookOpen className="h-4 w-4 shrink-0 text-muted-foreground" />
      </button>
      {open && (
        <div className="border-t border-border px-5 py-4 text-sm">
          <div className="whitespace-pre-wrap">{article.body}</div>
        </div>
      )}
    </Card>
  );
}

function FaqRow({
  faq,
}: {
  faq: { id: string; title: string; body: string };
}) {
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-5 py-4 text-left"
        data-testid={`faq-${faq.id}`}
      >
        <div className="font-medium">{faq.title}</div>
      </button>
      {open && (
        <div className="border-t border-border px-5 py-4 text-sm">
          <div className="whitespace-pre-wrap">{faq.body}</div>
        </div>
      )}
    </Card>
  );
}
