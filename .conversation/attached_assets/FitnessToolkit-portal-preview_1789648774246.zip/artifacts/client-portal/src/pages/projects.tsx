import { Link } from "wouter";
import { useListMyProjects } from "@workspace/api-client-react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { formatDate, statusLabel } from "@/lib/utils";

export default function ProjectsPage() {
  const { data, isLoading } = useListMyProjects();
  return (
    <AppShell>
      <PageHeader
        eyebrow="Done-for-you"
        title="Your projects"
        description="Where every active engagement lives — kickoff to delivery."
      />
      <div className="px-10 py-10">
        {isLoading ? (
          <div className="space-y-4">
            {[0, 1].map((i) => (
              <Skeleton key={i} className="h-32 rounded-2xl" />
            ))}
          </div>
        ) : data && data.length > 0 ? (
          <div className="space-y-4">
            {data.map((p) => (
              <Link key={p.id} href={`/projects/${p.id}`}>
                <a
                  data-testid={`project-card-${p.id}`}
                  className="block rounded-2xl border border-border bg-card p-6 transition-colors hover:border-foreground/40"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
                        {p.clientName || "Project"}
                      </div>
                      <div className="mt-1 font-display text-2xl text-foreground">
                        {p.title}
                      </div>
                      {p.description && (
                        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                          {p.description}
                        </p>
                      )}
                    </div>
                    <Badge
                      variant="outline"
                      className="border-foreground/20 text-foreground"
                    >
                      {statusLabel(p.status)}
                    </Badge>
                  </div>
                  <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-3">
                    <div>
                      <div className="mb-1.5 flex justify-between text-xs uppercase tracking-widest text-muted-foreground">
                        <span>Progress</span>
                        <span>{p.progressPct ?? 0}%</span>
                      </div>
                      <Progress value={p.progressPct ?? 0} className="h-1" />
                    </div>
                    <div>
                      <div className="text-xs uppercase tracking-widest text-muted-foreground">
                        Next milestone
                      </div>
                      <div className="mt-1 text-sm text-foreground">
                        {p.nextMilestone || "—"}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs uppercase tracking-widest text-muted-foreground">
                        Due
                      </div>
                      <div className="mt-1 text-sm text-foreground">
                        {formatDate(p.nextMilestoneDate)}
                      </div>
                    </div>
                  </div>
                </a>
              </Link>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 px-8 py-16 text-center">
            <div className="font-display text-2xl">No projects yet</div>
            <p className="mt-2 text-sm text-muted-foreground">
              When the team kicks off your project, it'll show up here.
            </p>
          </div>
        )}
      </div>
    </AppShell>
  );
}
