import { Rocket } from "lucide-react";
import { AppShell, PageHeader } from "@/components/AppShell";

export default function Upsell2Page() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="Premium track"
        title="Upsell 2"
        description="Second premium slot. Use it for a follow-up program, a high-ticket offer, or a community tier."
      />
      <div className="px-10 py-10">
        <div className="rounded-2xl border border-dashed border-border bg-card/50 px-8 py-16 text-center">
          <Rocket className="mx-auto h-10 w-10 text-foreground" strokeWidth={1.5} />
          <div className="mt-4 font-display text-2xl">Coming soon</div>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Reserved for your second premium upsell. Configure this page once
            you've decided what graduates of your master class should buy next.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
