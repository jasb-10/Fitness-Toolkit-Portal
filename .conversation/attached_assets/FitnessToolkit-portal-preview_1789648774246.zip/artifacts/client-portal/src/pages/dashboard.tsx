import { Link } from "wouter";
import { motion } from "framer-motion";
import { Play, ArrowRight } from "lucide-react";
import {
  useGetDashboard,
  useGetMe,
} from "@workspace/api-client-react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { VideoPlayer } from "@/components/VideoPlayer";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { formatDate, statusLabel } from "@/lib/utils";

export default function DashboardPage() {
  const { data: me } = useGetMe();
  const { data, isLoading } = useGetDashboard();

  return (
    <AppShell>
      <PageHeader
        eyebrow="Welcome back"
        title={me?.user.name ? me.user.name.split(" ")[0]! : "Hello"}
        description={
          data?.welcomeMessage ??
          "Your master class, your projects, your progress — all in one place."
        }
      />

      <div className="px-10 py-10">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="mb-3 text-xs font-medium uppercase tracking-[0.22em] text-muted-foreground">
              Welcome video
            </div>
            <div className="overflow-hidden rounded-2xl border border-border bg-card">
              <VideoPlayer url={data?.welcomeVideoUrl} />
            </div>
          </div>

          <div>
            <div className="mb-3 text-xs font-medium uppercase tracking-[0.22em] text-muted-foreground">
              Your progress
            </div>
            <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
              <Stat
                label="Master class complete"
                value={`${Math.round(data?.stats.completionPct ?? 0)}%`}
                loading={isLoading}
              />
              <Progress
                value={data?.stats.completionPct ?? 0}
                className="h-1.5"
              />
              <div className="grid grid-cols-3 gap-3 pt-3">
                <Stat
                  label="Lessons"
                  value={`${data?.stats.completedLessons ?? 0}/${
                    data?.stats.totalLessons ?? 0
                  }`}
                  loading={isLoading}
                  small
                />
                <Stat
                  label="Hours"
                  value={(data?.stats.hoursWatched ?? 0).toFixed(1)}
                  loading={isLoading}
                  small
                />
                <Stat
                  label="Streak"
                  value={`${data?.stats.streakDays ?? 0}d`}
                  loading={isLoading}
                  small
                />
              </div>
            </div>
          </div>
        </div>

        {/* Courses */}
        <section className="mt-16">
          <SectionHeader
            title="Your courses"
            link="/courses"
            linkLabel="See all"
          />
          {isLoading ? (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-44 rounded-2xl" />
              ))}
            </div>
          ) : data?.courses.length === 0 ? (
            <EmptyCard
              title="No courses yet"
              body="Once you're granted course access, your courses will appear here."
            />
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {data?.courses.map((c) => (
                <Link key={c.id} href={`/courses/${c.id}`}>
                  <a
                    data-testid={`dashboard-course-${c.id}`}
                    className="group block rounded-2xl border border-border bg-card p-6 transition-colors hover:border-foreground/40"
                  >
                    <div className="flex items-start justify-between">
                      <div className="font-display text-2xl text-foreground">
                        {c.title}
                      </div>
                      <ArrowRight className="h-4 w-4 translate-x-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
                    </div>
                    <div className="mt-6">
                      <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-widest text-muted-foreground">
                        <span>{Math.round(c.completionPct)}% complete</span>
                        <span>
                          {c.completedLessons}/{c.totalLessons} lessons
                        </span>
                      </div>
                      <Progress value={c.completionPct} className="h-1" />
                    </div>
                  </a>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* Continue learning */}
        <section className="mt-16">
          <SectionHeader title="Continue learning" />
          {isLoading ? (
            <Skeleton className="h-32 rounded-2xl" />
          ) : data?.recentLessons.length === 0 ? (
            <EmptyCard
              title="No recent lessons"
              body="Open any lesson to start tracking your place here."
            />
          ) : (
            <div className="overflow-hidden rounded-2xl border border-border bg-card">
              {data?.recentLessons.map((r) => (
                <Link
                  key={r.lessonId}
                  href={`/courses/${r.courseId}?lesson=${r.lessonId}`}
                >
                  <a
                    data-testid={`recent-lesson-${r.lessonId}`}
                    className="flex items-center gap-4 border-b border-border px-6 py-5 last:border-0 hover:bg-muted/40"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full border border-border">
                      <Play className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-foreground">
                        {r.lessonTitle}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {r.courseTitle} · {formatDate(r.lastAccessedAt)}
                      </div>
                    </div>
                    <div className="text-xs uppercase tracking-widest text-muted-foreground">
                      Resume
                    </div>
                  </a>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* DFY projects */}
        <section className="mt-16">
          <SectionHeader
            title="Your DFY projects"
            link="/projects"
            linkLabel="View all"
          />
          {isLoading ? (
            <Skeleton className="h-40 rounded-2xl" />
          ) : (data?.activeProjects ?? []).length === 0 ? (
            <EmptyCard
              title="No active projects"
              body="When the team kicks off a done-for-you project, it'll appear here."
            />
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {data?.activeProjects?.map((p) => (
                <Link key={p.id} href={`/projects/${p.id}`}>
                  <motion.a
                    data-testid={`dashboard-project-${p.id}`}
                    whileHover={{ y: -2 }}
                    className="block rounded-2xl border border-border bg-card p-6"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-display text-2xl text-foreground">
                          {p.title}
                        </div>
                        {p.nextMilestone && (
                          <div className="mt-1 text-sm text-muted-foreground">
                            Next: {p.nextMilestone}
                          </div>
                        )}
                      </div>
                      <Badge
                        variant="outline"
                        className="border-foreground/20 text-foreground"
                      >
                        {statusLabel(p.status)}
                      </Badge>
                    </div>
                    <div className="mt-6">
                      <div className="mb-2 flex justify-between text-xs uppercase tracking-widest text-muted-foreground">
                        <span>Progress</span>
                        <span>{p.progressPct ?? 0}%</span>
                      </div>
                      <Progress value={p.progressPct ?? 0} className="h-1" />
                    </div>
                  </motion.a>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}

function Stat({
  label,
  value,
  loading,
  small,
}: {
  label: string;
  value: string;
  loading?: boolean;
  small?: boolean;
}) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      {loading ? (
        <Skeleton className={small ? "mt-1 h-5 w-12" : "mt-1 h-8 w-20"} />
      ) : (
        <div
          className={
            small
              ? "mt-1 font-display text-xl text-foreground"
              : "mt-1 font-display text-3xl text-foreground"
          }
        >
          {value}
        </div>
      )}
    </div>
  );
}

function SectionHeader({
  title,
  link,
  linkLabel,
}: {
  title: string;
  link?: string;
  linkLabel?: string;
}) {
  return (
    <div className="mb-5 flex items-end justify-between">
      <h2 className="font-display text-2xl text-foreground">{title}</h2>
      {link && (
        <Link href={link}>
          <a className="text-xs font-medium uppercase tracking-widest text-muted-foreground hover:text-foreground">
            {linkLabel}
          </a>
        </Link>
      )}
    </div>
  );
}

function EmptyCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card/50 px-8 py-12 text-center">
      <div className="font-display text-xl text-foreground">{title}</div>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
        {body}
      </p>
    </div>
  );
}
