import { Sparkles } from "lucide-react";
import { AppShell, PageHeader } from "@/components/AppShell";

export default function Upsell1Page() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="Premium track"
        title="Upsell 1"
        description="Drop your premium add-on course here. Replace this placeholder with the curriculum you want to sell after the master class."
      />
      <div className="px-10 py-10">
        <div className="rounded-2xl border border-dashed border-border bg-card/50 px-8 py-16 text-center">
          <Sparkles className="mx-auto h-10 w-10 text-foreground" strokeWidth={1.5} />
          <div className="mt-4 font-display text-2xl">Coming soon</div>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            This is a placeholder slot for your first premium upsell. From the
            admin Courses tab, create a course titled "Upsell 1" and link it
            here, or wire this page to your sales flow.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
