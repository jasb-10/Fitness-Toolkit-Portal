import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { useListCourses } from "@workspace/api-client-react";
import { AppShell, PageHeader } from "@/components/AppShell";
import { Skeleton } from "@/components/ui/skeleton";
import { thumbnailUrl } from "@/components/ThumbnailUploader";

export default function CoursesPage() {
  const { data, isLoading } = useListCourses();
  return (
    <AppShell>
      <PageHeader
        eyebrow="Library"
        title="Master Class"
        description="Every course you've been granted access to. Click in to begin or pick up where you left off."
      />
      <div className="px-10 py-10">
        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-64 rounded-2xl" />
            ))}
          </div>
        ) : data && data.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {data.map((c) => {
              const thumb = thumbnailUrl(c.coverImageUrl);
              return (
              <Link key={c.id} href={`/courses/${c.id}`}>
                <a
                  data-testid={`course-card-${c.id}`}
                  className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-foreground/40"
                >
                  {thumb ? (
                    <img
                      src={thumb}
                      alt={c.title}
                      className="aspect-[16/10] w-full object-cover"
                    />
                  ) : (
                    <div className="aspect-[16/10] w-full bg-foreground" />
                  )}
                  <div className="flex flex-1 flex-col p-6">
                    <div className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
                      Course
                    </div>
                    <div className="mt-2 font-display text-2xl text-foreground">
                      {c.title}
                    </div>
                    {c.subtitle && (
                      <p className="mt-2 text-sm text-muted-foreground">
                        {c.subtitle}
                      </p>
                    )}
                    <div className="mt-auto flex items-center justify-between pt-6 text-xs uppercase tracking-widest text-muted-foreground">
                      <span>{c.totalLessons} lessons</span>
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                </a>
              </Link>
              );
            })}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 px-8 py-16 text-center">
            <div className="font-display text-2xl">No courses yet</div>
            <p className="mt-2 text-sm text-muted-foreground">
              Once a course is granted to your account, it'll appear here.
            </p>
          </div>
        )}
      </div>
    </AppShell>
  );
}
